// API Base URL
const API_BASE = 'http://localhost:8000';

// Global variables
let map;
let markers = [];
let updateInterval;

// Color mapping for incident types
const INCIDENT_COLORS = {
    "Accident": "#FF0000",
    "Fire": "#FFA500",
    "Harassment": "#8B0000",
    "Suspicious Activity": "#FFD700",
    "Unsafe Area": "#FF4500",
    "Traffic Issue": "#FF8C00",
    "Weather Conditions": "#4169E1"
};

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    initializeNavigation();
    initializeMap();
    initializeForm();
    loadDashboard();
    
    // Auto-refresh every 10 seconds
    updateInterval = setInterval(loadDashboard, 10000);
});

// Navigation
function initializeNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const section = link.getAttribute('data-section');
            switchSection(section);
        });
    });
}

function switchSection(sectionName) {
    // Update active nav link
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('data-section') === sectionName) {
            link.classList.add('active');
        }
    });

    // Update active section
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(sectionName).classList.add('active');

    // Reload dashboard when switching to it
    if (sectionName === 'dashboard') {
        loadDashboard();
    }
}

// Map initialization
function initializeMap() {
    // Initialize map centered on India
    map = L.map('map').setView([20.5937, 78.9629], 5);

    // Add OpenStreetMap tiles
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19
    }).addTo(map);

    // Try to get user location
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                map.setView([position.coords.latitude, position.coords.longitude], 13);
            },
            () => {
                console.log('Location access denied');
            }
        );
    }
}

// Update map with incidents
function updateMap(incidents) {
    if (!map) return; // Safety check
    
    // Clear existing markers
    markers.forEach(marker => {
        try {
            map.removeLayer(marker);
        } catch (e) {
            // Marker already removed
        }
    });
    markers = [];

    // Add markers for each incident
    if (!Array.isArray(incidents)) return;
    
    incidents.forEach(incident => {
        if (!incident) return;
        
        const lat = incident.latitude || 20.5937 + (Math.random() - 0.5) * 10;
        const lng = incident.longitude || 78.9629 + (Math.random() - 0.5) * 10;
        const color = incident.color || INCIDENT_COLORS[incident.incident_type] || '#808080';

        // Create custom icon
        const icon = L.divIcon({
            className: 'custom-marker',
            html: `<div style="background-color: ${color}; width: 20px; height: 20px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>`,
            iconSize: [20, 20],
            iconAnchor: [10, 10]
        });

        try {
            const marker = L.marker([lat, lng], { icon: icon }).addTo(map);
            
            // Popup content with safe escaping
            const incidentType = (incident.incident_type || 'Unknown').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            const location = (incident.location || 'Unknown').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            const description = (incident.description || '').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            const timestamp = incident.timestamp ? new Date(incident.timestamp).toLocaleString() : 'Unknown';
            const confidence = incident.confidence_score ? (incident.confidence_score * 100).toFixed(0) : '0';
            
            const popupContent = `
                <div style="min-width: 200px;">
                    <h3 style="margin: 0 0 0.5rem 0; color: ${color};">${incidentType}</h3>
                    <p style="margin: 0.25rem 0;"><strong>Location:</strong> ${location}</p>
                    <p style="margin: 0.25rem 0;">${description}</p>
                    <p style="margin: 0.25rem 0; font-size: 0.85rem; color: #666;">
                        ${timestamp}
                    </p>
                    <p style="margin: 0.25rem 0; font-size: 0.85rem;">
                        Confidence: ${confidence}%
                    </p>
                </div>
            `;
            
            marker.bindPopup(popupContent);
            markers.push(marker);
        } catch (e) {
            console.error('Error adding marker:', e);
        }
    });

    // Fit map to show all markers
    if (markers.length > 0) {
        try {
            const group = new L.featureGroup(markers);
            const bounds = group.getBounds();
            if (bounds.isValid()) {
                map.fitBounds(bounds.pad(0.1));
            }
        } catch (error) {
            console.log('Error fitting map bounds:', error);
        }
    }
}

// Load dashboard data
async function loadDashboard() {
    try {
        showLoading();
        
        const response = await fetch(`${API_BASE}/api/incidents`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        const incidents = data.incidents || [];

        // Update stats
        updateStats(incidents);

        // Update map
        updateMap(incidents);

        // Update incidents list
        updateIncidentsList(incidents);

        hideLoading();
    } catch (error) {
        console.error('Error loading dashboard:', error);
        hideLoading();
        // Show user-friendly error message
        const container = document.getElementById('incidents-list');
        if (container) {
            container.innerHTML = '<p style="text-align: center; color: white; padding: 2rem;">Unable to load incidents. Please check if the backend server is running.</p>';
        }
    }
}

// Update statistics
function updateStats(incidents) {
    if (!Array.isArray(incidents)) {
        incidents = [];
    }
    
    const total = incidents.length;
    const now = new Date();
    const recent = incidents.filter(inc => {
        if (!inc || !inc.timestamp) return false;
        try {
            const incTime = new Date(inc.timestamp);
            return (now - incTime) < 86400000; // 24 hours
        } catch (e) {
            return false;
        }
    }).length;
    const active = incidents.filter(inc => inc && !inc.is_spam && (inc.confidence_score || 0) > 0.5).length;

    const totalEl = document.getElementById('total-incidents');
    const recentEl = document.getElementById('recent-incidents');
    const activeEl = document.getElementById('active-alerts');
    
    if (totalEl) totalEl.textContent = total;
    if (recentEl) recentEl.textContent = recent;
    if (activeEl) activeEl.textContent = active;
}

// Update incidents list
function updateIncidentsList(incidents) {
    const container = document.getElementById('incidents-list');
    
    if (incidents.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: white; padding: 2rem;">No incidents reported yet.</p>';
        return;
    }

    // Sort by timestamp (newest first)
    const sorted = [...incidents].sort((a, b) => 
        new Date(b.timestamp) - new Date(a.timestamp)
    );

    container.innerHTML = sorted.map(incident => createIncidentCard(incident)).join('');
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Create incident card HTML
function createIncidentCard(incident) {
    if (!incident) return '';
    
    const color = incident.color || INCIDENT_COLORS[incident.incident_type] || '#808080';
    const badges = [];
    
    if (incident.is_spam) {
        badges.push('<span class="incident-badge badge-spam">Spam</span>');
    }
    if (incident.is_duplicate) {
        badges.push('<span class="incident-badge badge-duplicate">Duplicate</span>');
    }

    const incidentType = escapeHtml(incident.incident_type || 'Unknown');
    const location = escapeHtml(incident.location || 'Unknown');
    const description = escapeHtml(incident.description || '');
    const timestamp = incident.timestamp ? new Date(incident.timestamp).toLocaleString() : 'Unknown';
    const confidence = incident.confidence_score ? (incident.confidence_score * 100).toFixed(0) : '0';

    return `
        <div class="incident-card" style="border-left-color: ${color};">
            <div class="incident-header">
                <div class="incident-type" style="color: ${color};">
                    ${getIncidentIcon(incident.incident_type)} ${incidentType}
                </div>
                <div class="incident-confidence">
                    ${confidence}% confidence
                </div>
            </div>
            <div class="incident-location">
                📍 ${location}
            </div>
            <div class="incident-description">
                ${description}
            </div>
            <div class="incident-footer">
                <span>${timestamp}</span>
                <span>${badges.join('')}</span>
            </div>
        </div>
    `;
}

// Get icon for incident type
function getIncidentIcon(type) {
    const icons = {
        "Accident": "🚗",
        "Fire": "🔥",
        "Harassment": "🚨",
        "Suspicious Activity": "👁️",
        "Unsafe Area": "⚠️",
        "Traffic Issue": "🚦",
        "Weather Conditions": "🌧️"
    };
    return icons[type] || "📍";
}

// Form initialization
function initializeForm() {
    const form = document.getElementById('incident-form');
    const detectBtn = document.getElementById('detect-location');
    const locationInput = document.getElementById('location');

    // Detect location button
    detectBtn.addEventListener('click', () => {
        if (navigator.geolocation) {
            detectBtn.textContent = '⏳ Detecting...';
            detectBtn.disabled = true;
            
            navigator.geolocation.getCurrentPosition(
                async (position) => {
                    const lat = position.coords.latitude;
                    const lng = position.coords.longitude;
                    
                    // Reverse geocoding (simple version - you can use a geocoding API)
                    try {
                        const response = await fetch(
                            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`,
                            {
                                headers: {
                                    'User-Agent': 'SafeScape/1.0'
                                }
                            }
                        );
                        if (response.ok) {
                            const data = await response.json();
                            locationInput.value = data.display_name || `${lat}, ${lng}`;
                        } else {
                            locationInput.value = `${lat}, ${lng}`;
                        }
                    } catch (error) {
                        console.log('Geocoding error:', error);
                        locationInput.value = `${lat}, ${lng}`;
                    }
                    
                    document.getElementById('latitude').value = lat;
                    document.getElementById('longitude').value = lng;
                    
                    detectBtn.textContent = '📍 Detect';
                    detectBtn.disabled = false;
                },
                (error) => {
                    alert('Unable to detect location. Please enter manually.');
                    detectBtn.textContent = '📍 Detect';
                    detectBtn.disabled = false;
                }
            );
        } else {
            alert('Geolocation is not supported by your browser.');
        }
    });

    // Form submission
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const submitBtn = form.querySelector('button[type="submit"]');
        const loader = submitBtn.querySelector('.btn-loader');
        const messageDiv = document.getElementById('form-message');
        
        submitBtn.disabled = true;
        loader.style.display = 'inline';
        messageDiv.className = 'form-message';
        messageDiv.style.display = 'none';

        try {
            const formData = new FormData(form);
            
            const response = await fetch(`${API_BASE}/api/incidents`, {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (response.ok) {
                messageDiv.className = 'form-message success';
                messageDiv.textContent = data.message || 'Incident reported successfully!';
                messageDiv.style.display = 'block';
                form.reset();
                
                // Reload dashboard after 1 second
                setTimeout(() => {
                    switchSection('dashboard');
                    loadDashboard();
                }, 1000);
            } else {
                throw new Error(data.message || 'Failed to submit incident');
            }
        } catch (error) {
            messageDiv.className = 'form-message error';
            messageDiv.textContent = error.message || 'An error occurred. Please try again.';
            messageDiv.style.display = 'block';
        } finally {
            submitBtn.disabled = false;
            loader.style.display = 'none';
        }
    });
}

// Loading overlay
function showLoading() {
    document.getElementById('loading-overlay').classList.add('active');
}

function hideLoading() {
    document.getElementById('loading-overlay').classList.remove('active');
}

