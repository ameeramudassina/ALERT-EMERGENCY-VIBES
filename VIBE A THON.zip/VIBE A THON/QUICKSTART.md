# 🚀 SafeScape - Quick Start Guide

## ⚡ 3-Step Setup (5 minutes)

### Step 1: Install Backend Dependencies
```bash
cd backend
pip install -r requirements.txt
```

### Step 2: Start Backend Server
```bash
python app.py
```
Server runs at: `http://localhost:8000`

### Step 3: Open Frontend
**Option A:** Double-click `frontend/index.html` (works but CORS may block API calls)

**Option B (Recommended):** Use a local server:
```bash
# Python
cd frontend
python -m http.server 8080

# Or Node.js
npx http-server frontend -p 8080
```

Then open: `http://localhost:8080`

## ✅ Verify It Works

1. Backend is running → Visit `http://localhost:8000` → Should see `{"message": "SafeScape API is running"}`
2. Frontend loads → See the dashboard with map
3. Submit a test incident → Fill form and submit
4. Check dashboard → Incident should appear on map and in list

## 🎯 All Features Included

✅ Interactive Dashboard with Stats  
✅ Incident Reporting Form (7 types)  
✅ Geo Heat Map (Leaflet.js)  
✅ Real-time Updates (10-second polling)  
✅ AI Spam Detection  
✅ Duplicate Detection  
✅ Confidence Scoring  
✅ Color-coded Markers  
✅ Image Upload Support  
✅ Location Auto-detection  
✅ Modern, Animated UI  

## 🐛 Troubleshooting

**Port 8000 already in use?**
- Change port in `backend/app.py` line 277: `uvicorn.run(app, host="0.0.0.0", port=8001)`
- Update `API_BASE` in `frontend/app.js` to match

**CORS errors?**
- Make sure backend is running
- Use a local server for frontend (not file://)

**Map not loading?**
- Check internet connection (Leaflet needs CDN)
- Check browser console for errors

## 🎨 Customization Tips

- **Change colors:** Edit `INCIDENT_COLORS` in `backend/app.py` and `frontend/app.js`
- **Change update interval:** Edit `setInterval` in `frontend/app.js` (line ~20)
- **Add more incident types:** Add to form options and color mapping

---

**Ready to hack! 🚀**

