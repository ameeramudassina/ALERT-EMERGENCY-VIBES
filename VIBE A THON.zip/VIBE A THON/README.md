# 🛡️ SafeScape - Community Safety Alert System

An interactive, hyperlocal community safety alert system built for hackathons. Report incidents, view real-time alerts, and stay informed about safety in your community.

## ✨ Features

- **Interactive Dashboard** - Real-time incident monitoring with statistics
- **Incident Reporting** - Report various types of incidents (Accident, Fire, Harassment, Suspicious Activity, Unsafe Area, Traffic Issue, Weather Conditions)
- **Geo Heat Map** - Visual representation of incidents using Leaflet.js
- **AI-Powered Filtering** - Automatic spam detection, duplicate detection, and confidence scoring
- **Real-Time Updates** - Auto-refresh every 10 seconds
- **Modern UI** - Clean, minimal, and engaging interface

## 🚀 Quick Start

### Prerequisites

- Python 3.8+
- Modern web browser

### Installation

1. **Install Backend Dependencies**

```bash
cd backend
pip install -r requirements.txt
```

2. **Start the Backend Server**

```bash
python app.py
```

The API will be running at `http://localhost:8000`

3. **Open Frontend**

Open `frontend/index.html` in your web browser, or use a local server:

```bash
# Using Python
cd frontend
python -m http.server 8080

# Using Node.js (if you have it)
npx http-server frontend -p 8080
```

Then open `http://localhost:8080` in your browser.

## 📁 Project Structure

```
safescape/
├── backend/
│   ├── app.py              # FastAPI backend server
│   ├── requirements.txt    # Python dependencies
│   └── data/
│       ├── incidents.json  # Incident storage (auto-created)
│       └── uploads/        # Uploaded images (auto-created)
├── frontend/
│   ├── index.html         # Main HTML file
│   ├── style.css          # Stylesheet
│   └── app.js             # Frontend JavaScript
└── README.md              # This file
```

## 🎯 API Endpoints

### GET `/api/incidents`
Get all incidents

### POST `/api/incidents`
Submit a new incident report

**Form Data:**
- `incident_type` (required): Type of incident
- `location` (required): Location description
- `description` (required): Incident description
- `latitude` (optional): Latitude coordinate
- `longitude` (optional): Longitude coordinate
- `image` (optional): Image file

### GET `/api/stats`
Get statistics about incidents

## 🎨 Incident Types & Colors

- 🚗 **Accident** - Red (#FF0000)
- 🔥 **Fire** - Orange (#FFA500)
- 🚨 **Harassment** - Dark Red (#8B0000)
- 👁️ **Suspicious Activity** - Gold (#FFD700)
- ⚠️ **Unsafe Area** - Orange Red (#FF4500)
- 🚦 **Traffic Issue** - Dark Orange (#FF8C00)
- 🌧️ **Weather Conditions** - Royal Blue (#4169E1)

## 🤖 AI Features

### Spam Detection
- Keyword filtering
- Length validation
- Repetition detection

### Duplicate Detection
- Location-based matching
- Time-based filtering (5-minute window)
- Category matching

### Confidence Scoring
Based on:
- Description length
- Location accuracy
- Image availability
- Spam/duplicate flags

## 🔧 Configuration

### Change API URL
Edit `API_BASE` in `frontend/app.js`:

```javascript
const API_BASE = 'http://localhost:8000';
```

### Change Update Interval
Edit the interval in `frontend/app.js`:

```javascript
updateInterval = setInterval(loadDashboard, 10000); // 10 seconds
```

## 📝 Notes

- Data is stored in JSON format for simplicity
- Images are stored in `backend/data/uploads/`
- The map defaults to India but can be adjusted
- Location detection uses browser geolocation API

## 🐛 Troubleshooting

**Backend not starting:**
- Ensure Python 3.8+ is installed
- Install dependencies: `pip install -r requirements.txt`
- Check if port 8000 is available

**Frontend not loading:**
- Ensure backend is running
- Check browser console for errors
- Verify CORS settings if accessing from different origin

**Map not showing:**
- Check internet connection (Leaflet.js requires internet)
- Verify Leaflet.js CDN is accessible

## 🎉 Hackathon Ready!

This project is designed to be:
- ✅ Fast to set up
- ✅ Easy to customize
- ✅ Fully functional MVP
- ✅ Production-ready code structure

## 📄 License

MIT License - Feel free to use for your hackathon project!

---

Built with ❤️ for SafeScape Hackathon

