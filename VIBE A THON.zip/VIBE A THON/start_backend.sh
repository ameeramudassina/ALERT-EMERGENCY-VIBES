#!/bin/bash
echo "Starting SafeScape Backend Server..."
cd backend
pip install -r requirements.txt
python app.py

