from fastapi import FastAPI, File, UploadFile, Form  # type: ignore
from fastapi.middleware.cors import CORSMiddleware  # type: ignore
from datetime import datetime
import json
import uuid
from typing import Optional
from pathlib import Path

app = FastAPI(title="SafeScape API")

# CORS middleware for frontend access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Data directory
DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)
INCIDENTS_FILE = DATA_DIR / "incidents.json"

# Initialize incidents file if it doesn't exist
if not INCIDENTS_FILE.exists():
    with open(INCIDENTS_FILE, "w") as f:
        json.dump([], f)

# Color codes for incident types
INCIDENT_COLORS = {
    "Accident": "#FF0000",  # Red
    "Fire": "#FFA500",      # Orange
    "Harassment": "#8B0000", # Dark Red
    "Suspicious Activity": "#FFD700", # Gold
    "Unsafe Area": "#FF4500", # Orange Red
    "Traffic Issue": "#FF8C00", # Dark Orange
    "Weather Conditions": "#4169E1" # Royal Blue
}

# Spam keywords
SPAM_KEYWORDS = ["test", "fake", "spam", "ignore", "not real", "just testing"]

def load_incidents():
    """Load incidents from JSON file"""
    try:
        with open(INCIDENTS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, IOError):
        return []

def save_incidents(incidents):
    """Save incidents to JSON file"""
    try:
        with open(INCIDENTS_FILE, "w", encoding="utf-8") as f:
            json.dump(incidents, f, indent=2, ensure_ascii=False)
    except IOError as e:
        print(f"Error saving incidents: {e}")
        raise

def detect_spam(description: str) -> bool:
    """Rule-based spam detection"""
    description_lower = description.lower()
    
    # Check for spam keywords
    for keyword in SPAM_KEYWORDS:
        if keyword in description_lower:
            return True
    
    # Check for very short descriptions (likely spam)
    if len(description.strip()) < 10:
        return True
    
    # Check for excessive repetition
    words = description_lower.split()
    if len(words) > 0:
        unique_ratio = len(set(words)) / len(words)
        if unique_ratio < 0.3:  # Too much repetition
            return True
    
    return False

def detect_duplicate(incidents: list, new_incident: dict) -> bool:
    """Detect duplicate reports based on location, category, and timestamp"""
    new_location = new_incident.get("location", "").lower()
    new_type = new_incident.get("incident_type", "")
    
    try:
        new_time = datetime.fromisoformat(new_incident.get("timestamp", ""))
    except (ValueError, TypeError):
        return False
    
    for incident in incidents:
        existing_location = incident.get("location", "").lower()
        existing_type = incident.get("incident_type", "")
        
        try:
            existing_time = datetime.fromisoformat(incident.get("timestamp", ""))
        except (ValueError, TypeError):
            continue
        
        # Check if same type and location
        if existing_type == new_type and existing_location == new_location:
            # Check if within 5 minutes (likely duplicate)
            time_diff = abs((new_time - existing_time).total_seconds())
            if time_diff < 300:  # 5 minutes
                return True
    
    return False

def classify_incident(description: str, incident_type: str) -> str:
    """Classify and validate incident type based on description"""
    description_lower = description.lower()
    
    # Keyword mapping for classification
    keywords = {
        "Accident": ["accident", "crash", "collision", "vehicle", "car", "hit"],
        "Fire": ["fire", "smoke", "burning", "flame", "blaze"],
        "Harassment": ["harassment", "harass", "threat", "abuse", "molest"],
        "Suspicious Activity": ["suspicious", "strange", "unusual", "weird", "odd"],
        "Unsafe Area": ["unsafe", "dangerous", "risk", "hazard", "threat"],
        "Traffic Issue": ["traffic", "jam", "congestion", "blocked", "road"],
        "Weather Conditions": ["weather", "rain", "storm", "flood", "wind", "snow"]
    }
    
    # If type matches keywords, keep it; otherwise try to classify
    if incident_type in keywords:
        for keyword in keywords[incident_type]:
            if keyword in description_lower:
                return incident_type
    
    # Try to classify based on description
    for inc_type, kw_list in keywords.items():
        for keyword in kw_list:
            if keyword in description_lower:
                return inc_type
    
    # Default to provided type
    return incident_type

def calculate_confidence_score(incident: dict) -> float:
    """Calculate confidence score (0-1) for incident validity"""
    score = 0.5  # Base score
    
    description = incident.get("description", "")
    
    # Longer descriptions are more credible
    if len(description) > 50:
        score += 0.2
    elif len(description) > 20:
        score += 0.1
    
    # Has location
    if incident.get("location"):
        score += 0.1
    
    # Has coordinates (more precise)
    if incident.get("latitude") and incident.get("longitude"):
        score += 0.1
    
    # Has image (more credible)
    if incident.get("image_path"):
        score += 0.1
    
    # Not flagged as spam
    if not incident.get("is_spam", False):
        score += 0.1
    
    # Not a duplicate
    if not incident.get("is_duplicate", False):
        score += 0.1
    
    return min(score, 1.0)

@app.get("/")
def root():
    return {"message": "SafeScape API is running"}

@app.get("/api/incidents")
def get_incidents():
    """Get all incidents"""
    incidents = load_incidents()
    return {"incidents": incidents, "count": len(incidents)}

@app.post("/api/incidents")
async def submit_incident(
    incident_type: str = Form(...),
    location: str = Form(...),
    description: str = Form(...),
    latitude: Optional[float] = Form(None),
    longitude: Optional[float] = Form(None),
    image: Optional[UploadFile] = File(None)
):
    """Submit a new incident report"""
    
    # Load existing incidents
    incidents = load_incidents()
    
    # Create incident object
    incident_id = str(uuid.uuid4())
    timestamp = datetime.now().isoformat()
    
    # Handle image upload
    image_path = None
    if image and image.filename:
        upload_dir = DATA_DIR / "uploads"
        upload_dir.mkdir(exist_ok=True)
        file_extension = image.filename.split(".")[-1] if "." in image.filename else "jpg"
        image_path = f"uploads/{incident_id}.{file_extension}"
        file_path = DATA_DIR / image_path
        
        try:
            with open(file_path, "wb") as f:
                content = await image.read()
                f.write(content)
        except Exception as e:
            print(f"Error saving image: {e}")
            image_path = None
    
    # Create incident
    incident = {
        "id": incident_id,
        "incident_type": incident_type,
        "location": location,
        "description": description,
        "latitude": latitude,
        "longitude": longitude,
        "timestamp": timestamp,
        "image_path": image_path,
        "is_spam": False,
        "is_duplicate": False,
        "confidence_score": 0.5
    }
    
    # AI Processing
    # 1. Spam detection
    is_spam = detect_spam(description)
    incident["is_spam"] = is_spam
    
    # 2. Duplicate detection
    is_duplicate = detect_duplicate(incidents, incident)
    incident["is_duplicate"] = is_duplicate
    
    # 3. Classification
    incident["incident_type"] = classify_incident(description, incident_type)
    
    # 4. Confidence score
    incident["confidence_score"] = calculate_confidence_score(incident)
    
    # Add color based on type
    incident["color"] = INCIDENT_COLORS.get(incident["incident_type"], "#808080")
    
    # Only add if not spam (or if spam but low confidence)
    if not is_spam or incident["confidence_score"] > 0.3:
        incidents.append(incident)
        save_incidents(incidents)
    
    return {
        "success": True,
        "incident": incident,
        "message": "Incident reported successfully" if not is_spam else "Incident flagged for review"
    }

@app.get("/api/stats")
def get_stats():
    """Get statistics about incidents"""
    incidents = load_incidents()
    
    stats = {
        "total": len(incidents),
        "by_type": {},
        "recent": 0
    }
    
    # Count by type
    for incident in incidents:
        inc_type = incident.get("incident_type", "Unknown")
        stats["by_type"][inc_type] = stats["by_type"].get(inc_type, 0) + 1
    
    # Count recent (last 24 hours)
    now = datetime.now()
    for incident in incidents:
        try:
            inc_time = datetime.fromisoformat(incident.get("timestamp", ""))
            if (now - inc_time).total_seconds() < 86400:  # 24 hours
                stats["recent"] += 1
        except (ValueError, TypeError):
            continue
    
    return stats

if __name__ == "__main__":
    import uvicorn  # type: ignore
    uvicorn.run(app, host="0.0.0.0", port=8000)

